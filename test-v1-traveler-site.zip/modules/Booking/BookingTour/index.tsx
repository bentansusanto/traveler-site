export const BookingTour = () => {
  return (
    <div>
      <BookingTour />
    </div>
  );
};
